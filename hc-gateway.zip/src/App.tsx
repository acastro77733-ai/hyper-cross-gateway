/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/// <reference types="vite/client" />
import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import { Mail, ArrowRight, CheckCircle2, Clock, ShieldCheck, Wallet, ArrowUpRight, ArrowDownLeft, Settings, Activity, Globe, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Magic } from 'magic-sdk';
import { createWeb3Modal, defaultConfig, useWeb3Modal, useWeb3ModalAccount, useWeb3ModalProvider } from '@web3modal/ethers/react';

// --- Web3Modal Configuration ---
const projectId = import.meta.env.VITE_WALLETCONNECT_PROJECT_ID || '5bfa9c8d646441ac48e1e416de0b7773';

const mainnet = {
  chainId: 1,
  name: 'Ethereum',
  currency: 'ETH',
  explorerUrl: 'https://etherscan.io',
  rpcUrl: 'https://cloudflare-eth.com'
};

const metadata = {
  name: 'HC Gateway',
  description: 'Secure Web3 Gateway',
  url: window.location.origin,
  icons: ['https://avatars.githubusercontent.com/u/37784886']
};

createWeb3Modal({
  ethersConfig: defaultConfig({ metadata }),
  chains: [mainnet],
  projectId,
  enableAnalytics: true
});

// --- Magic.link & Ethers Setup ---
let magic: any = null;
if (import.meta.env.VITE_MAGIC_PUBLISHABLE_KEY) {
  magic = new Magic(import.meta.env.VITE_MAGIC_PUBLISHABLE_KEY);
}

const KALEIDO_RPC_URL = import.meta.env.VITE_KALEIDO_RPC_URL || 'https://mock-rpc.kaleido.io';

// Mock Data
const MOCK_TRADES = [
  { id: 'TRD-8X92', type: 'buy', amount: 500, status: 'locked', partner: 'alice@example.com', date: '2026-03-28' },
  { id: 'TRD-4M11', type: 'sell', amount: 1200, status: 'completed', partner: 'bob@example.com', date: '2026-03-27' },
];

const TesseractCross = ({ className = "" }: { className?: string }) => (
  <div className={`tesseract-container ${className}`}>
    <div className="tesseract">
      <div className="tesseract-face front"></div>
      <div className="tesseract-face back"></div>
      <div className="tesseract-face right"></div>
      <div className="tesseract-face left"></div>
      <div className="tesseract-face top"></div>
      <div className="tesseract-face bottom"></div>
      
      <div className="inner-tesseract">
        <div className="inner-face inner-front"></div>
        <div className="inner-face inner-back"></div>
        <div className="inner-face inner-right"></div>
        <div className="inner-face inner-left"></div>
        <div className="inner-face inner-top"></div>
        <div className="inner-face inner-bottom"></div>
      </div>
    </div>
  </div>
);

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [email, setEmail] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  
  const [balance, setBalance] = useState('0.00');
  const [secureAccount, setSecureAccount] = useState('');
  const [provider, setProvider] = useState<ethers.JsonRpcProvider | null>(null);
  
  const { open } = useWeb3Modal();
  const { address, isConnected } = useWeb3ModalAccount();
  const { walletProvider } = useWeb3ModalProvider();

  const [showTradeModal, setShowTradeModal] = useState(false);
  const [showSetup, setShowSetup] = useState(false);
  const [isSettingUp, setIsSettingUp] = useState(false);
  const [setupStatus, setSetupStatus] = useState<{ success?: boolean; message?: string } | null>(null);

  useEffect(() => {
    // Initialize Ethers Provider (Kaleido JSON-RPC)
    try {
      const newProvider = new ethers.JsonRpcProvider(KALEIDO_RPC_URL);
      setProvider(newProvider);
    } catch (error) {
      console.error("Failed to initialize provider:", error);
    }
  }, []);

  // Live Balance Updates
  useEffect(() => {
    let interval: any;
    
    const fetchBalance = async () => {
      if (isConnected && walletProvider) {
        try {
          const ethersProvider = new ethers.BrowserProvider(walletProvider);
          const signer = await ethersProvider.getSigner();
          const addr = await signer.getAddress();
          const bal = await ethersProvider.getBalance(addr);
          setBalance(parseFloat(ethers.formatEther(bal)).toFixed(4));
          setSecureAccount(addr.substring(0, 6) + '...' + addr.substring(addr.length - 4));
        } catch (error) {
          console.error("Error fetching live balance:", error);
        }
      } else if (isLoggedIn && magic) {
        try {
          const magicProvider = new ethers.BrowserProvider(magic.rpcProvider);
          const signer = await magicProvider.getSigner();
          const addr = await signer.getAddress();
          // For demo, we still use mock balance for Magic if no real funds
          // setBalance('2,450.00'); 
        } catch (error) {
          console.error("Error fetching magic balance:", error);
        }
      }
    };

    if (isConnected || isLoggedIn) {
      fetchBalance();
      interval = setInterval(fetchBalance, 5000); // Update every 5 seconds
    }

    return () => clearInterval(interval);
  }, [isConnected, isLoggedIn, walletProvider]);

  useEffect(() => {
    if (isConnected && address) {
      setIsLoggedIn(true);
      setSecureAccount(address.substring(0, 6) + '...' + address.substring(address.length - 4));
    }
  }, [isConnected, address]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    if (!magic) {
      alert("SYSTEM ERROR: VITE_MAGIC_PUBLISHABLE_KEY is missing. Cannot establish live secure link.");
      return;
    }

    setIsLoggingIn(true);
    
    try {
      await magic.auth.loginWithMagicLink({ email });
      const magicProvider = new ethers.BrowserProvider(magic.rpcProvider);
      const signer = await magicProvider.getSigner();
      const address = await signer.getAddress();
      setSecureAccount(address.substring(0, 6) + '...' + address.substring(address.length - 4));
      
      // In a real app, we would fetch the balance from the contract here
      // const contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, signer);
      // const bal = await contract.balanceOf(address);
      setBalance('2,450.00'); 
      
      setIsLoggedIn(true);
    } catch (error: any) {
      console.error("Magic login failed", error);
      const errorMessage = error?.message || String(error);
      
      if (errorMessage.includes("User canceled action")) {
        // User closed the popup, no need to show a scary alert
        console.log("Login sequence aborted by user.");
      } else if (errorMessage.includes("has not approved access")) {
        alert(`ACCESS DENIED: Domain not whitelisted.\n\nPlease add this URL to your Magic.link Dashboard allowed domains:\n${window.location.origin}`);
      } else {
        alert("LOGIN FAILED: " + errorMessage);
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    if (magic) {
      await magic.user.logout();
    }
    setIsLoggedIn(false);
    setEmail('');
    setSecureAccount('');
    setBalance('0.00');
  };

  const handleSetupIdentityProvider = async () => {
    setIsSettingUp(true);
    setSetupStatus(null);
    try {
      const response = await fetch("/api/magic/identity-provider", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          // These will use server-side defaults if not provided here
          // issuer: "https://your-auth-provider.com",
          // audience: "your-app-audience",
          // jwks_uri: "https://your-auth-provider.com/.well-known/jwks.json"
        }),
      });
      const data = await response.json();
      if (response.ok) {
        setSetupStatus({ success: true, message: "IDENTITY PROVIDER REGISTERED SUCCESSFULLY" });
      } else {
        setSetupStatus({ success: false, message: `SETUP FAILED: ${data.error || JSON.stringify(data)}` });
      }
    } catch (error) {
      console.error("Setup error:", error);
      setSetupStatus({ success: false, message: "NETWORK ERROR DURING SETUP" });
    } finally {
      setIsSettingUp(false);
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen circuit-bg flex flex-col items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full glass-card p-8 space-y-8"
        >
          <div className="text-center space-y-4">
            <div className="mx-auto flex justify-center mb-12 mt-4">
              <TesseractCross />
            </div>
            <h1 className="text-4xl font-bold text-gold uppercase tracking-widest drop-shadow-lg">HC Gateway</h1>
            <p className="text-xl text-gold opacity-80 font-mono">AUTHORIZED PERSONNEL ONLY</p>
          </div>

          <div className="space-y-4">
            <button
              onClick={() => open()}
              className="w-full flex justify-center items-center py-4 px-4 glass-btn text-2xl"
            >
              <Globe className="mr-3 h-6 w-6" />
              CONNECT WALLET
            </button>

            <div className="relative flex items-center py-2">
              <div className="flex-grow border-t border-gold/20"></div>
              <span className="flex-shrink mx-4 text-gold/40 text-sm uppercase">or secure link</span>
              <div className="flex-grow border-t border-gold/20"></div>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-6 w-6 text-gold opacity-50" />
                </div>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  className="block w-full pl-12 pr-3 py-4 glass-input text-xl"
                  placeholder="OPERATIVE_EMAIL@HC.GATEWAY"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isLoggingIn}
                />
              </div>

              <button
                type="submit"
                disabled={isLoggingIn || !email}
                className="w-full flex justify-center items-center py-4 px-4 glass-btn text-2xl disabled:opacity-50"
              >
                {isLoggingIn ? (
                  <Activity className="animate-spin mr-3 h-6 w-6" />
                ) : (
                  <Zap className="mr-3 h-6 w-6" />
                )}
                {isLoggingIn ? "LINKING..." : "MAGIC LINK"}
              </button>
            </form>
          </div>
          
          <div className="text-center mt-8 border-t border-gold/20 pt-4 space-y-4">
            <p className="text-lg text-gold opacity-60">SECURED BY MAGIC.LINK & KALEIDO</p>
            {!magic && <p className="text-sm text-umbrella-red mt-2 font-bold animate-pulse">CRITICAL ERROR: VITE_MAGIC_PUBLISHABLE_KEY MISSING. LIVE LINK OFFLINE.</p>}
            
            <div className="pt-4">
              <button 
                onClick={() => setShowSetup(!showSetup)}
                className="text-sm text-gold opacity-40 hover:opacity-100 transition-opacity flex items-center justify-center mx-auto uppercase"
              >
                <Settings className="w-4 h-4 mr-2" />
                System Configuration
              </button>
            </div>

            <AnimatePresence>
              {showSetup && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <div className="bg-dark-royal border border-gold border-opacity-30 p-4 space-y-4 mt-2">
                    <p className="text-sm text-gold opacity-80 uppercase">Register Identity Provider with Magic Labs TEE</p>
                    <button
                      onClick={handleSetupIdentityProvider}
                      disabled={isSettingUp}
                      className="w-full pixel-btn-secondary py-2 text-lg flex items-center justify-center disabled:opacity-50"
                    >
                      {isSettingUp ? (
                        <Activity className="w-5 h-5 mr-2 animate-pulse" />
                      ) : (
                        <ShieldCheck className="w-5 h-5 mr-2" />
                      )}
                      {isSettingUp ? "PROCESSING..." : "REGISTER IDENTITY PROVIDER"}
                    </button>
                    {setupStatus && (
                      <p className={`text-xs font-bold uppercase ${setupStatus.success ? 'text-green-400' : 'text-umbrella-red'}`}>
                        {setupStatus.message}
                      </p>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen circuit-bg pb-20">
      {/* Header */}
      <header className="glass-card rounded-none border-t-0 border-l-0 border-r-0 sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="scale-40 origin-left -my-8">
              <TesseractCross />
            </div>
            <span className="text-3xl font-bold tracking-widest uppercase text-gold drop-shadow-md">HC Gateway</span>
          </div>
          <div className="flex items-center space-x-6">
            <div className="hidden sm:flex items-center text-xl text-gold bg-royal/40 backdrop-blur-md border border-gold/30 px-4 py-1 rounded-full">
              <Wallet className="w-5 h-5 mr-2" />
              {secureAccount}
            </div>
            <button 
              onClick={handleLogout}
              className="text-xl font-medium text-gold hover:text-umbrella-red transition-colors uppercase tracking-tighter"
            >
              TERMINATE
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        {/* Balance Card */}
        <section>
          <div className="glass-card p-6 sm:p-10 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-20 group-hover:opacity-40 transition-opacity">
              <Zap className="w-20 h-20 text-gold" />
            </div>
            <div className="relative z-10">
              <p className="text-2xl opacity-60 mb-2 uppercase tracking-widest">Live Resource Allocation</p>
              <div className="flex items-baseline space-x-3">
                <h2 className="text-6xl sm:text-8xl font-bold tracking-tight text-umbrella-red drop-shadow-[0_0_15px_rgba(204,0,0,0.5)]">{balance}</h2>
                <span className="text-3xl font-medium uppercase text-gold/80">ETH</span>
              </div>
              
              <div className="mt-10 flex flex-col sm:flex-row gap-4">
                <button 
                  onClick={() => setShowTradeModal(true)}
                  className="flex-1 glass-btn py-5 px-6 flex items-center justify-center text-2xl"
                >
                  <ArrowUpRight className="w-7 h-7 mr-3" />
                  INITIATE TRANSFER
                </button>
                <button className="flex-1 glass-btn-secondary py-5 px-6 flex items-center justify-center text-2xl">
                  <ArrowDownLeft className="w-7 h-7 mr-3" />
                  AWAIT INCOMING
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Active Trades */}
        <section className="space-y-4">
          <div className="flex items-center justify-between border-b border-gold/20 pb-2">
            <h3 className="text-3xl font-bold uppercase tracking-widest text-gold/80">Active Operations</h3>
            <button className="text-xl text-umbrella-red hover:text-gold uppercase transition-colors">View Log</button>
          </div>
          
          <div className="glass-card overflow-hidden">
            <ul className="divide-y divide-gold/10">
              {MOCK_TRADES.map((trade) => (
                <li key={trade.id} className="p-6 hover:bg-white/5 transition-colors cursor-pointer group">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-5">
                      <div className={`w-14 h-14 rounded-xl border border-gold/30 flex items-center justify-center transition-transform group-hover:scale-110 ${trade.type === 'buy' ? 'bg-umbrella-red/20' : 'bg-royal/40'}`}>
                        {trade.type === 'buy' ? <ArrowUpRight className="w-7 h-7 text-umbrella-red" /> : <ArrowDownLeft className="w-7 h-7 text-gold" />}
                      </div>
                      <div>
                        <p className="text-2xl font-medium uppercase tracking-tight">
                          {trade.type === 'buy' ? 'TARGET:' : 'SOURCE:'} {trade.partner.split('@')[0]}
                        </p>
                        <p className="text-lg opacity-50 font-mono">REF: {trade.id}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-3xl font-bold ${trade.type === 'buy' ? 'text-umbrella-red' : 'text-gold'}`}>
                        {trade.type === 'buy' ? '-' : '+'}{trade.amount} CR
                      </p>
                      <div className="flex items-center justify-end mt-2">
                        {trade.status === 'locked' ? (
                          <span className="inline-flex items-center text-lg font-medium text-gold bg-royal/30 backdrop-blur-sm border border-gold/20 px-4 py-1 rounded-full uppercase">
                            <Clock className="w-4 h-4 mr-2" />
                            IN ESCROW
                          </span>
                        ) : (
                          <span className="inline-flex items-center text-lg font-medium text-white bg-umbrella-red/40 backdrop-blur-sm border border-gold/30 px-4 py-1 rounded-full uppercase">
                            <CheckCircle2 className="w-4 h-4 mr-2" />
                            CLEARED
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {/* Escrow Action Area */}
                  {trade.status === 'locked' && trade.type === 'buy' && (
                    <div className="mt-6 pt-4 border-t border-dashed border-gold/20 flex items-center justify-between">
                      <p className="text-xl text-gold/70 uppercase">AWAITING CONFIRMATION OF ASSET ACQUISITION.</p>
                      <button className="text-xl font-medium glass-btn px-8 py-2">
                        CONFIRM RECEIPT
                      </button>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </section>

      </main>

      {/* Quick Trade Modal */}
      <AnimatePresence>
        {showTradeModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-0">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 backdrop-blur-md"
              onClick={() => setShowTradeModal(false)}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 40 }}
              className="relative glass-card w-full max-w-lg overflow-hidden z-10"
            >
              <div className="p-8">
                <div className="flex items-center space-x-5 mb-10 border-b border-gold/20 pb-6">
                  <div className="scale-40 origin-left -my-8">
                    <TesseractCross />
                  </div>
                  <h3 className="text-3xl font-bold uppercase tracking-widest text-umbrella-red drop-shadow-md">NEW OPERATION</h3>
                </div>
                
                <form className="space-y-8" onSubmit={(e) => { e.preventDefault(); setShowTradeModal(false); }}>
                  <div>
                    <label className="block text-xl font-medium mb-3 uppercase text-gold/70">Target Operative (Email)</label>
                    <input 
                      type="email" 
                      required
                      placeholder="OPERATIVE@HC.GATEWAY"
                      className="w-full px-5 py-5 glass-input text-xl"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xl font-medium mb-3 uppercase text-gold/70">Resource Allocation (Credits)</label>
                    <div className="relative">
                      <input 
                        type="number" 
                        required
                        min="1"
                        placeholder="0.00"
                        className="w-full pl-5 pr-20 py-5 glass-input text-3xl font-bold"
                      />
                      <div className="absolute inset-y-0 right-0 pr-6 flex items-center pointer-events-none">
                        <span className="text-2xl font-medium opacity-50">CR</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-royal/20 border border-umbrella-red/30 p-5 rounded-2xl flex items-start space-x-5">
                    <ShieldCheck className="w-10 h-10 text-umbrella-red shrink-0 mt-1" />
                    <p className="text-lg text-gold/80 uppercase leading-snug">
                      <strong className="text-umbrella-red block mb-2 text-xl">ESCROW PROTOCOL ENGAGED:</strong> 
                      Resources will be locked in secure holding. Target cannot access funds until you confirm acquisition.
                    </p>
                  </div>

                  <div className="pt-8 flex gap-4">
                    <button 
                      type="button"
                      onClick={() => setShowTradeModal(false)}
                      className="flex-1 glass-btn-secondary py-5 text-2xl"
                    >
                      ABORT
                    </button>
                    <button 
                      type="submit"
                      className="flex-1 glass-btn py-5 text-2xl"
                    >
                      AUTHORIZE
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

